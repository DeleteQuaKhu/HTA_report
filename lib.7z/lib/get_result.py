import csv

class NodeTemperature:
    def __init__(self):
        # Initialize an empty dictionary to store node IDs and their temperatures
        self.node_temperatures = {}

    def add_node_temperature(self, node_id, temperature):
        """
        Adds or updates the temperature for a given node.
        """
        self.node_temperatures[node_id] = temperature

    def get_temperature(self, node_id):
        """
        Returns the temperature for a given node ID.
        If the node does not exist, return a message.
        """
        return self.node_temperatures.get(node_id, "Node ID not found")

    def display_all_temperatures(self):
        """
        Displays all nodes and their corresponding temperatures.
        """
        for node_id, temperature in self.node_temperatures.items():
            print(f"Node {node_id}: {temperature}°C")

    def load_from_csv(self, file_path):
        with open(file_path, mode='r') as file:
            csv_reader = csv.reader(file)

            # Skip the first line which contains the 'process_number'
            next(csv_reader)

            # Read the header to extract node IDs from the temperature columns
            header = next(csv_reader)

            # Extract node IDs from columns that start with "Temperature"
            node_ids = []
            for col in header:
                if col.startswith("Temperature"):
                    node_id = int(col.split()[-1])
                    node_ids.append(node_id)

            # Read the subsequent rows and load the temperature data
            for row in csv_reader:
                temperatures = row[2:]  # Skip 'Step' and 'Time' columns
                for i, temp in enumerate(temperatures):
                    self.add_node_temperature(node_ids[i], float(temp))