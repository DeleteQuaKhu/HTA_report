def create_adx_file(node_ids, file_path, adx_file):
    # Open the file for writing
    with open(file_path, 'w') as file:
        # Loop through each node_id and write the repeating section
        file.write(f"##################################\n")
        file.write(f"$OutputHistoryNode\n")
        file.write(f"##################################\n")
        file.write(f"output_history_file_id = {adx_file}\n")
        file.write(f"process_id=Proc1\n")
        file.write(f"output_last=yes\n\n")
        for node_id in node_ids:
            file.write(f"{node_id} 0 Temperature\n")
    
    print(f"File created successfully at {file_path}")


# # Example usage
# node_list = [123, 124, 221, 222, 223]
# file_path = 'output_history.adx'
# create_adx_file(node_list, file_path)
