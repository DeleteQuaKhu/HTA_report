import openpyxl
def insert_values_to_excel(file_path, sheet_name, node, result):
    # Load the workbook and select the specified sheet
    workbook = openpyxl.load_workbook(file_path)
    
    if sheet_name not in workbook.sheetnames:
        print(f"Sheet '{sheet_name}' not found in {file_path}.")
        return
    
    sheet = workbook[sheet_name]

    sheet["G5"] = node
    sheet["H5"] = result
    
    # Save the workbook after inserting the values
    workbook.save(file_path)
    print(f"Data successfully inserted into {file_path}, sheet: {sheet_name}")